package com.ucsc.conditions;

import java.util.ArrayList;

public class Runner {
    public static void main(String[] args) {
        boolean value = false;
        if (value == true) {
            System.out.println("The value is true");
        } else if (value == false) {
            System.out.println("The value is false");
        }

        //Arrays
        String[] fruits = {"Apple", "Orange", "Guava"};
        if (fruits[0] == "Apple") {
            System.out.println("This is Apple");
        } else if (fruits[1] == "Orange") {
            System.out.println("This is the Orange");
        } else {
            System.out.println("This is the Guava");
        }

        //nested if
        String name = "John";
        int age = 23;
        if (name == "John") {
            if (age == 23) {
                System.out.println("John is 23 ");
            }
        }

        int number = 35;
        if (number % 2 == 0) {
            System.out.println("This is a even number");
        } else {
            System.out.println("This is a odd number");
        }

        //swith case

        int num1 = 10;
        int num2 = 5;
        char operator = '*';

        switch (operator) {
            case ('*'):
                System.out.println(num1 * num2);
                break;

            case ('+'):
                System.out.println(num1 + num2);

            default:
                System.out.println("error");
        }


        //max value

        int a = 23;
        int b = 24;
        int c = 26;

        if (a >= b && a >= c) {
            System.out.println("The max value is: " + a);

        }

    }

}










