package com.ucsc.training;

import java.util.ArrayList;

public class Dog {
    String bark= "is barking";

    public String bark(){
        String name= "Lucy";
//        System.out.println(name+bark);
        return name;
    }

    public ArrayList<String> eat(){
        ArrayList<String> foods= new ArrayList<>();

        foods.add("bread");
        foods.add("tomato");
        return foods;
    }


}
