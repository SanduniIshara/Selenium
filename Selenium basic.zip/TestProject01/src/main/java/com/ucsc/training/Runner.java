package com.ucsc.training;

import java.util.ArrayList;

public class Runner {
    public static void main( String[] args ){
        Dog dog=new Dog();
        dog.bark();

        ArrayList<String> eatValue = dog.eat();
        System.out.println(eatValue);
    }
}
