package com.ucsc.assignment;

public class Employee {
    private String name;
    private int age;


    public Employee(String name, int age){
        this.name = name;
        this.age= age;
    }

    public double calculateSalry() {
        return 0;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }


    public static String companyName() {
        return "TechCorp";
    }

}

