package com.ucsc.assignment;

public interface Bonus {

    double getBonus();

}
