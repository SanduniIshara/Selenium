package com.ucsc.assignment;

public class Developer extends  Employee implements Bonus{
    private double baseSalary;

    public Developer(String name, int age, int i){
        super(name, age);
        this.baseSalary=baseSalary;
    }


    @Override
    public double getBonus(){
        return this.baseSalary*0.1;
    }

    @Override
    public double calculateSalry() {
        return baseSalary+this.getBonus();
    }


}
