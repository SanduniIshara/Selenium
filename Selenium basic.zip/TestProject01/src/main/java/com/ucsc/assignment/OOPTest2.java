//package com.ucsc.assignment;
//
//public class OOPTest2 {
//
//    public static void main(String[] args) {
//        Developer developer = new Developer("Ishara", 25, 50000);
//        Manager manager = new Manager("Sandui", 23, 60000);
//
//        System.out.println("Developer Details:");
//        developer.displayDeveloperInfo();
//        System.out.println("Total Salary: " + developer.calculateSalary() + "\n");
//
//    }
//
//
//
//}
