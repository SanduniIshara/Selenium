package com.ucsc.assignment;

public class Manager extends  Employee implements Bonus{

    private double baseSalary;

    public Manager(String name, int age, double baseSalary ){
        super(name, age);
        this.baseSalary=baseSalary;
    }

    @Override
    public double getBonus(){
        return this.baseSalary*0.1;
    }

    @Override
    public double calculateSalry() {
        return baseSalary+this.getBonus();
    }
}
