package selenium;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class MainClassTest {
    public static void main(String[] args) {
//        System.setProperty("webdriver.chromedriver.driver","C:\\Users\\hp\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();  //based on the browser that we are preferred we can enter the name here like chromeDriver
        driver.get("https://www.google.com/");

        //get current url
        String currentURL = driver.getCurrentUrl();
        System.out.println("Current URL is: "+currentURL);

        //command for navigate to another URL
        driver.navigate().to("https://www.ebay.com/");

        //go back to previous URL
        driver.navigate().back();

        //forward to 2nd URL(ebay)
        driver.navigate().forward();

        //refresh
        driver.navigate().refresh();

        //maximize the window
        driver.manage().window().maximize();

        //get cookies
        Set<Cookie> cookies =  driver.manage().getCookies();

        for(Cookie cookie : cookies){
            System.out.println("Cookie name : "+cookie.getName());
            System.out.println("Cookie value : "+ cookie.getValue());
        }

        //add cookie
        Cookie customCookie = new Cookie("customerCookie", "custmValue");
        driver.manage().addCookie(customCookie);

        //get a cookie
        Cookie returnCookie = driver.manage().getCookieNamed("customerCookie");
        returnCookie.getValue();

        //find element
        driver.findElement(By.xpath("//input[@placeholder='Search for anything']"));

        driver.findElement(By.xpath("//input[@placeholder='Search for anything']")).sendKeys("smart watches"); //search something in the texbox

        //driver.findElement(By.xpath("//input[@placeholder='Search for anything']")).clear();  //clear the search value in the tex box

        //driver.findElement(By.xpath("//input[@value='Search']")).click();  //instead of this we can use bellow code line click with a variable

        WebElement element = driver.findElement(By.xpath("//input[@value='Search']"));
        element.click();  //using click like this we can reuse this variable if we need execute later

        //homework
        // navigate to para bank page and click two buttons
        driver.navigate().to("https://parabank.parasoft.com/parabank/index.htm;jsessionid=E62B459201510612B412DDE50AA7E52F");
        driver.findElement(By.xpath("//a[text()='Admin Page']")).click();
        WebElement rdoButton = driver.findElement(By.xpath("//input[@value='soap']"));
        if(rdoButton.isSelected()){
            rdoButton.click();
        }


        //dropdown
        WebElement dd_LoanProvider = driver.findElement(By.xpath("//select[@name='loanProvider']"));

        //explicitWait
        WebDriverWait webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(30));
        webDriverWait.until(ExpectedConditions.visibilityOf(dd_LoanProvider));    //explicit wait is only for a specific object , this is essential to put right before the that specific object

        Select select = new Select(dd_LoanProvider);
        //select by visible text
        select.selectByVisibleText("Local");
        //select by index
        select.selectByIndex(1);  //we can select using index also index 1 belongs to Web Service
        //select by value
        select.selectByValue("jms");

        //Implicit wait
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);  //right after this code line our every code line get 10 seconds to execute each.
                                                                               // implicitWait is for the all objects right after this code line

        //fluent wait
        //derived class from wait class, in this wait it doesn't wait until the assigned time is out, it checks twice within this time period
        // if the time is 10 min , it checks the element in 5 min and again check in 10 min for the elements
        FluentWait<WebDriver> fluentWait = new FluentWait<>(driver).
                withTimeout(Duration.ofSeconds(30)).
                pollingEvery(Duration.ofSeconds(5)).
                ignoring(NoSuchElementException.class);
        fluentWait.until(ExpectedConditions.visibilityOf(dd_LoanProvider));

        //identify multiple elements
        List<WebElement> dd_options = driver.findElements(By.xpath("//select[@name='loanProvider']/option"));
        for(WebElement option : dd_options){
            System.out.println(option.getText());
        }

        //Alert
        driver.navigate().to("https://the-internet.herokuapp.com/javascript_alerts");
        driver.findElement(By.xpath("//button[@onclick='jsConfirm()']")).click();
        Alert alert = driver.switchTo().alert();
        System.out.println(alert.getText());
        alert.dismiss();
        WebElement getTextAlert = driver.findElement(By.xpath("//p[@id='result']"));
        System.out.println(getTextAlert.getText());

        //Switch to tabs
        //put a debug mark here and manually navigate another tab and check out this code by using watchers whether this is navigated to the new tab and type car on it
        String initialTab = driver.getWindowHandle();
        Set<String> allTabs = driver.getWindowHandles();
        for(String tab : allTabs){
            if(!tab.equals(initialTab)){
                driver.switchTo().window(tab);
            }
        }
        driver.findElement(By.xpath("//textarea[@name='q']")).sendKeys("cars");
        driver.close();
        driver.switchTo().window(initialTab); //again navigate to the previous tab



        //close
//        driver.close();
//        driver.quit();
    }
}

