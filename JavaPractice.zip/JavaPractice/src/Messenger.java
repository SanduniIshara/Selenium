public class Messenger {
    public void sendMessage(){
        System.out.println("Hello this is messenger class");
    }
}
