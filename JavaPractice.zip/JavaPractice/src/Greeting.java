public class Greeting {
    public void hello(){
        System.out.println("Heey i'm new");
    }
}
